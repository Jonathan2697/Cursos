# Sistema de Información de Estudiantes en PHP y MySQL
<img src="Sistema%20de%20Información%20de%20Estudiantes%20en%20PHP%20y%20MySQL.png">
Este Sistema de Información de Estudiantes en PHP y MySQL le permite al usuario administrativo ingresar la información de los estudiantes, según su departamento y curso.
</br></br>Esta aplicación es totalmente gratuita, para su utilización requieres la base de datos que se encuentra en el siguiente enlace:
</br></br><a href="https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#Sistema-de-Informaci%C3%B3n-de-Estudiantes-en-PHP-y-MySQL">Sistema de Información de Estudiantes en PHP y MySQL</a>
