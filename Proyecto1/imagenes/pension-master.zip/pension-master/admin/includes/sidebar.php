<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">ConfiguroWeb</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Consola</a></li>
					<li><a href="#"><i class="fa fa-files-o"></i> Cursos</a>
					<ul>
						<li><a href="add-courses.php">Agregar Cursos</a></li>
						<li><a href="manage-courses.php">Administrar Cursos</a></li>
					</ul>
				</li>
					<li><a href="#"><i class="fa fa-desktop"></i> Cuartos</a>
					<ul>
						<li><a href="create-room.php">Agregar un Cuarto</a></li>
						<li><a href="manage-rooms.php">Administrar Cuartos</a></li>
					</ul>
				</li>

				<li><a href="registration.php"><i class="fa fa-user"></i>Registro de Estudiantes</a></li>
				<li><a href="manage-students.php"><i class="fa fa-users"></i>Administrar Estudiantes</a></li>
				<li><a href="access-log.php"><i class="fa fa-file"></i>Registro de Acceso de Usuarios</a></li>

			
		</nav>