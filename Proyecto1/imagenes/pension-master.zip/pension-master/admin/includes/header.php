<div class="brand clearfix">
		<a href="#" class="logo" style="font-size:16px;">LaPensión|<b>ConfiguroWeb</b></a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Cuenta <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="admin-profile.php">Mi Cuenta</a></li>
					<li><a href="logout.php">Cerrar Sesión</a></li>
				</ul>
			</li>
		</ul>
	</div>