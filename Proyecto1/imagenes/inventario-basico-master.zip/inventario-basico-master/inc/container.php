</head>

<body class="bg-gradient bg-dark bg-opacity-25">
  <nav role="navigation" class="navbar navbar-dark navbar-static-top bg-info bg-gradient">
    <div class="container">
      <div class="navbar-header">
        <a href="https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#Aplicaciones-gratuitas-en-PHP,-Python-y-Javascript" target="_blank" class="navbar-brand">Sistema Básico de Inventario - PHP</a>
      </div>
    </div>
  </nav>

  <div class="container">