<footer>
    <h3 class="text-center my-4 py-3 text-light" id="title">Para más desarrollos accede a <a href="https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#Aplicaciones-gratuitas-en-PHP,-Python-y-Javascript" target="_blank" style="color:white;text-decoration:none;">ConfiguroWeb</a></h3>
</footer>